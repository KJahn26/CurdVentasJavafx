# CrudVentaDeProductos
Aplicación en java que permite administrar las ventas de productos que se hacen a los clientes de un almacén.
